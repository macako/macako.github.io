package com.walmart.hexagonalarchiecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexagonalArchiectureApplication {

	public static void main(String[] args) {
		SpringApplication.run(HexagonalArchiectureApplication.class, args);
	}

}
