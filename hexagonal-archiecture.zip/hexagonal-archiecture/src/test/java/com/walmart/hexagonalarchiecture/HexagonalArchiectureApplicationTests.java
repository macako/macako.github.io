package com.walmart.hexagonalarchiecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexagonalArchiectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
